﻿global using $ext_safeprojectname$.Business.Common.Exceptions;
global using $ext_safeprojectname$.Business.Common.Interfaces;