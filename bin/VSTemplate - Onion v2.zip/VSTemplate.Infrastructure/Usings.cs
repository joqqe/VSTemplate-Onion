﻿global using $ext_safeprojectname$.Infrastructure.Persistence;
global using Microsoft.EntityFrameworkCore;