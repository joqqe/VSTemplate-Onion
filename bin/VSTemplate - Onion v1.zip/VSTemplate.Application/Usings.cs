﻿global using $ext_safeprojectname$.Application.Common.Exceptions;
global using $ext_safeprojectname$.Application.Common.Interfaces;