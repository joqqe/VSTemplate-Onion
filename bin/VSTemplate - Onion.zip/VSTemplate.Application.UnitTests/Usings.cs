global using Xunit;
global using $ext_safeprojectname$.Infrastructure.Persistence;
global using $ext_safeprojectname$.Infrastructure;
global using Microsoft.Data.Sqlite;
global using Microsoft.EntityFrameworkCore;